class ProgressManager {
  // Uygulama geneli canlı veriler
  static int wpm = 286;
  static int comprehensionRate = 90;
  static int attentionSuccess = 85;
  static int completedExercises = 24;
  static int currentLevel = 3;
  static double levelProgress = 0.72; // %72

  static List<Map<String, String>> history = [
    {'title': 'Hızlı Okuma', 'result': '286 WPM', 'date': 'Bugün'},
    {'title': 'Dikkat', 'result': '%85', 'date': 'Bugün'},
    {'title': 'Anlama', 'result': '%90', 'date': 'Dün'},
    {'title': 'Hızlı Okuma', 'result': '264 WPM', 'date': 'Dün'},
  ];

  // Egzersiz tamamlandığında çağrılacak metot
  static void addCompletedExercise({
    required String type,
    required String result,
    int? newWpm,
  }) {
    completedExercises++;

    if (newWpm != null && newWpm > wpm) {
      wpm = newWpm; // Yeni rekor WPM
    }

    // İlerleme çubuğunu artır
    levelProgress += 0.10;
    if (levelProgress >= 1.0) {
      levelProgress = 0.20;
      currentLevel++; // Seviye atladı!
    }

    // Geçmişe ekle
    history.insert(0, {
      'title': type,
      'result': result,
      'date': 'Şimdi',
    });
  }

  // İlerlemeyi tamamen sıfırlama metodu
  static void resetProgress() {
    wpm = 200;
    comprehensionRate = 0;
    attentionSuccess = 0;
    completedExercises = 0;
    currentLevel = 1;
    levelProgress = 0.0;
    history.clear();
  }
}