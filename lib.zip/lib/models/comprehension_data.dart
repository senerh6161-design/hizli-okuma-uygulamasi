class ReadingPassage {
  final String id;
  final String title;
  final String content;
  final List<Map<String, dynamic>> questions;

  const ReadingPassage({
    required this.id,
    required this.title,
    required this.content,
    required this.questions,
  });
}

class ComprehensionData {
  static const List<ReadingPassage> passages = [
    ReadingPassage(
      id: 'p1',
      title: 'Hızlı Okuma ve Beyin Kasları',
      content:
          'Hızlı okuma, yalnızca gözlerin metin üzerinde hızla kayması değil, beynin görsel verileri işleme kapasitesini artırma sürecidir. İnsan gözü bir kelimeye odaklandığında sıçrama ve duraklama hareketleri yapar. Doğru egzersizlerle bu duraklama süreleri azaltılabilir ve gözün tek bir bakışta algıladığı kelime sayısı artırılabilir.',
      questions: [
        {
          'question': 'Metne göre hızlı okuma sürecinde asıl amaç nedir?',
          'answers': [
            'Gözleri yormak',
            'Beynin verileri işleme kapasitesini artırmak',
            'Kelime atlayarak okumak',
            'Sadece sayfa sayısını bitirmek'
          ],
          'correct': 1,
        },
        {
          'question': 'İnsan gözü okuma sırasında hangi hareketleri yapar?',
          'answers': [
            'Sıçrama ve duraklama',
            'Dairesel dönme',
            'Geriye doğru tarama',
            'Sabit kalma'
          ],
          'correct': 0,
        },
        {
          'question': 'Doğru egzersizlerle aşağıdakilerden hangisi sağlanır?',
          'answers': [
            'Duraklama süresi uzar',
            'Göz sağlığı bozulur',
            'Tek bakışta algılanan kelime sayısı artar',
            'Okuma isteği azalır'
          ],
          'correct': 2,
        },
      ],
    ),
    ReadingPassage(
      id: 'p2',
      title: 'Yapay Zekânın Geleceği',
      content:
          'Yapay zekâ teknolojileri, günümüzde veri analizi ve kalıp tanıma yetenekleriyle insan hayatını kolaylaştırmaktadır. Özellikle mühendislik ve tıp alanında karmaşık problemleri saniyeler içinde çözebilmektedir. Ancak yapay zekânın başarısı, eğitildiği verilerin kalitesine ve doğruluğuna doğrudan bağlıdır.',
      questions: [
        {
          'question': 'Yapay zekânın başarısı neye bağlıdır?',
          'answers': [
            'İnternet hızına',
            'Eğitildiği verilerin kalitesine',
            'Bilgisayarın rengine',
            'Kullanılan dilin zorluğuna'
          ],
          'correct': 1,
        },
        {
          'question': 'Metne göre yapay zekâ hangi alanlarda karmaşık problemleri çözer?',
          'answers': [
            'Mühendislik ve tıp',
            'Spor ve edebiyat',
            'Aşçılık ve müzik',
            'Moda ve mimari'
          ],
          'correct': 0,
        },
        {
          'question': 'Yapay zekâ temel olarak hangi yetenekleriyle öne çıkar?',
          'answers': [
            'Duygusal tepki verme',
            'Veri analizi ve kalıp tanıma',
            'Hayal kurma',
            'Fiziksel hareket etme'
          ],
          'correct': 1,
        },
      ],
    ),
    ReadingPassage(
      id: 'p3',
      title: 'Arıların Doğa İçindeki Önemi',
      content:
          'Arılar, ekosistemin sürdürülebilirliği için kritik bir role sahiptir. Çiçekler arasında polen taşıyarak bitkilerin tozlaşmasını sağlarlar. Dünya üzerindeki tarımsal ürünlerin büyük bir kısmı arıların bu polenleme faaliyetine bağımlıdır. Arı nüfusunun azalması, küresel gıda güvenliği için ciddi bir tehdittir.',
      questions: [
        {
          'question': 'Arıların bitkilere en büyük katkısı nedir?',
          'answers': [
            'Yaprakları temizlemek',
            'Polen taşıyarak tozlaşmayı sağlamak',
            'Toprağı havalandırmak',
            'Zararlı böcekleri yemek'
          ],
          'correct': 1,
        },
        {
          'question': 'Arı nüfusunun azalması neyi tehdit eder?',
          'answers': [
            'Deniz seviyelerini',
            'Rüzgâr hızını',
            'Küresel gıda güvenliğini',
            'Hava kalitesini'
          ],
          'correct': 2,
        },
        {
          'question': 'Metnin ana fikri aşağıdakilerden hangisidir?',
          'answers': [
            'Arı balının faydaları',
            'Arıların doğa ve gıda üretimi için hayati önemi',
            'Çiçek türlerinin çeşitliliği',
            'Tarım araçlarının kullanımı'
          ],
          'correct': 1,
        },
      ],
    ),
  ];
}