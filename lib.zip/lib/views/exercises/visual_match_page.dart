import 'dart:async';
import 'package:flutter/material.dart';
import '../../models/progress_manager.dart';

class VisualMatchPage extends StatefulWidget {
  const VisualMatchPage({super.key});

  @override
  State<VisualMatchPage> createState() => _VisualMatchPageState();
}

class _VisualMatchPageState extends State<VisualMatchPage> {
  // Eşleştirilecek İkon Havuzu
  final List<IconData> availableIcons = [
    Icons.card_giftcard,
    Icons.laptop,
    Icons.menu_book,
    Icons.beach_access,
    Icons.directions_car,
    Icons.watch,
    Icons.headphones,
    Icons.camera_alt,
  ];

  late List<IconData> gameBoard;
  List<bool> revealed = [];
  int? firstSelectedIndex;
  int pairsLeft = 0;
  int elapsedSeconds = 0;
  Timer? timer;
  bool isBusy = false;

  @override
  void initState() {
    super.initState();
    _startNewGame();
  }

  void _startNewGame() {
    timer?.cancel();
    // 6 Çift = 12 Kart
    List<IconData> selectedIcons = List.from(availableIcons)..shuffle();
    List<IconData> pairs = selectedIcons.take(6).toList();
    
    gameBoard = [...pairs, ...pairs]..shuffle(); // 2'şer tane yapıp karıştır
    revealed = List.filled(gameBoard.length, false);
    pairsLeft = 6;
    firstSelectedIndex = null;
    elapsedSeconds = 0;
    isBusy = false;

    timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (mounted) setState(() => elapsedSeconds++);
    });

    setState(() {});
  }

  void _onCardTap(int index) {
    if (isBusy || revealed[index] || firstSelectedIndex == index) return;

    setState(() {
      revealed[index] = true;
    });

    if (firstSelectedIndex == null) {
      // İlk kart seçildi
      firstSelectedIndex = index;
    } else {
      // İkinci kart seçildi, kontrol et
      isBusy = true;
      int firstIndex = firstSelectedIndex!;

      if (gameBoard[firstIndex] == gameBoard[index]) {
        // EŞLEŞTİ!
        setState(() {
          pairsLeft--;
          firstSelectedIndex = null;
          isBusy = false;
        });

        if (pairsLeft == 0) {
          timer?.cancel();
          ProgressManager.addCompletedExercise(
            type: 'Görsel Eşleştirme',
            result: '$elapsedSeconds sn',
          );
          _showWinDialog();
        }
      } else {
        // EŞLEŞMEDİ! 0.8 saniye gösterip kapat
        Timer(const Duration(milliseconds: 800), () {
          if (mounted) {
            setState(() {
              revealed[firstIndex] = false;
              revealed[index] = false;
              firstSelectedIndex = null;
              isBusy = false;
            });
          }
        });
      }
    }
  }

  void _showWinDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('🎉 Muhteşem Görsel Algı!'),
        content: Text('Tüm eşleri $elapsedSeconds saniyede buldunuz.'),
        actions: [
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _startNewGame();
            },
            child: const Text('Yeniden Oyna'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('🧩 Görsel Çift Eşleştirme'),
      ),
      body: Column(
        children: [
          // ÜST ÜNVAN & BİLGİ BARI
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
            color: Colors.white,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Kalan Çift: $pairsLeft',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF4F46E5)),
                ),
                Text(
                  'Süre: $elapsedSeconds sn',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.orange),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),

          // KART MATRIX ALANI
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: GridView.builder(
                itemCount: gameBoard.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                ),
                itemBuilder: (context, index) {
                  final isRevealed = revealed[index];

                  return InkWell(
                    onTap: () => _onCardTap(index),
                    borderRadius: BorderRadius.circular(20),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      decoration: BoxDecoration(
                        color: isRevealed ? Colors.white : const Color(0xFF4F46E5),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: isRevealed ? const Color(0xFF4F46E5) : Colors.transparent,
                          width: 2,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.08),
                            blurRadius: 6,
                          )
                        ],
                      ),
                      child: Center(
                        child: isRevealed
                            ? Icon(
                                gameBoard[index],
                                size: 40,
                                color: const Color(0xFF4F46E5),
                              )
                            : const Icon(
                                Icons.help_outline_rounded,
                                size: 36,
                                color: Colors.white,
                              ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),

          // YENİDEN BAŞLAT BUTONU
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF4F46E5),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                onPressed: _startNewGame,
                icon: const Icon(Icons.refresh),
                label: const Text(
                  'OYUNU SIFIRLA',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}