import 'dart:math';
import 'package:flutter/material.dart';
import '../../models/comprehension_data.dart';

class ComprehensionPage extends StatefulWidget {
  const ComprehensionPage({super.key});

  @override
  State<ComprehensionPage> createState() => _ComprehensionPageState();
}

class _ComprehensionPageState extends State<ComprehensionPage> {
  final Random random = Random();

  late ReadingPassage currentPassage;
  bool isReadingPhase = true; // Önce okuma aşaması, sonra soru aşaması
  int questionIndex = 0;
  int score = 0;

  @override
  void initState() {
    super.initState();
    _loadRandomPassage();
  }

  void _loadRandomPassage() {
    setState(() {
      // Havuzdan rastgele bir metin seçilir
      currentPassage = ComprehensionData
          .passages[random.nextInt(ComprehensionData.passages.length)];
      isReadingPhase = true;
      questionIndex = 0;
      score = 0;
    });
  }

  void answer(int selectedIndex) {
    if (selectedIndex ==
        currentPassage.questions[questionIndex]['correct']) {
      score++;
    }

    if (questionIndex < currentPassage.questions.length - 1) {
      setState(() {
        questionIndex++;
      });
    } else {
      _finish();
    }
  }

  void _finish() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('📝 Test Sonucu'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Metin: ${currentPassage.title}'),
            const SizedBox(height: 8),
            Text(
              '${currentPassage.questions.length} sorudan $score tanesini doğru yaptınız.',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              'Anlama Oranı: %${((score / currentPassage.questions.length) * 100).round()}',
              style: const TextStyle(
                color: Colors.indigo,
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
          ],
        ),
        actions: [
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _loadRandomPassage(); // Yeni farklı metne geç
            },
            child: const Text('Yeni Metin & Test'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('📝 Anlama Testi'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: isReadingPhase ? _buildReadingView() : _buildQuizView(),
      ),
    );
  }

  // 1. AŞAMA: PARAGRAF OKUMA EKRANI
  Widget _buildReadingView() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: Colors.indigo.shade50,
            borderRadius: BorderRadius.circular(8),
          ),
          child: const Text(
            '1. AŞAMA: METNİ OKUYUN',
            style: TextStyle(
              color: Colors.indigo,
              fontWeight: FontWeight.bold,
              fontSize: 12,
            ),
          ),
        ),
        const SizedBox(height: 16),
        Text(
          currentPassage.title,
          style: const TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: Color(0xFF0F172A),
          ),
        ),
        const SizedBox(height: 16),
        Expanded(
          child: SingleChildScrollView(
            child: Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.grey.shade300),
              ),
              child: Text(
                currentPassage.content,
                style: const TextStyle(
                  fontSize: 17,
                  height: 1.6,
                  color: Colors.black87,
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(
          width: double.infinity,
          height: 52,
          child: ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF4F46E5),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
            ),
            onPressed: () {
              setState(() {
                isReadingPhase = false; // Sorulara geç
              });
            },
            icon: const Icon(Icons.arrow_forward),
            label: const Text(
              'OKUDUM, TESTE GEÇ',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
          ),
        ),
      ],
    );
  }

  // 2. AŞAMA: SORU ÇÖZME EKRANI
  Widget _buildQuizView() {
    final currentQuestion = currentPassage.questions[questionIndex];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Soru ${questionIndex + 1}/${currentPassage.questions.length}',
              style: const TextStyle(
                color: Colors.indigo,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
            Text(
              currentPassage.title,
              style: const TextStyle(color: Colors.grey, fontSize: 13),
            ),
          ],
        ),
        const SizedBox(height: 20),
        Text(
          currentQuestion['question'],
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Color(0xFF0F172A),
          ),
        ),
        const SizedBox(height: 25),
        Expanded(
          child: ListView.builder(
            itemCount: currentQuestion['answers'].length,
            itemBuilder: (context, index) {
              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                child: OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.all(18),
                    alignment: Alignment.centerLeft,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  onPressed: () => answer(index),
                  child: Text(
                    '${String.fromCharCode(65 + index)}) ${currentQuestion['answers'][index]}',
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: Colors.black87,
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}