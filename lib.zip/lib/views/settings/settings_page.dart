import 'package:flutter/material.dart';
import '../../models/progress_manager.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool isFocusRed = true;
  bool isSoundOn = false;
  bool isReminderOn = true;

  // Kullanıcının seçtiği hatırlatıcı saati
  TimeOfDay reminderTime = const TimeOfDay(hour: 20, minute: 0);

  // Saat Seçme Penceresi (TimePicker)
  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: reminderTime,
    );
    if (picked != null && picked != reminderTime) {
      setState(() {
        reminderTime = picked;
      });
    }
  }

  // İlerlemeyi Sıfırlama Onay Penceresi
  void _showResetDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('İlerlemeyi Sıfırla'),
        content: const Text(
          'Tüm egzersiz geçmişiniz, seviyeniz ve istatistikleriniz sıfırlanacak. Emin misiniz?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('İptal'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
            onPressed: () {
              setState(() {
                ProgressManager.resetProgress();
              });
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Tüm ilerleme başarıyla sıfırlandı! 🔄'),
                  backgroundColor: Colors.redAccent,
                ),
              );
            },
            child: const Text('Sıfırla', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('⚙️ Ayarlar & Profil'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // PROFİL KARTI
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  const CircleAvatar(
                    radius: 30,
                    backgroundColor: Color(0xFF4F46E5),
                    child: Icon(Icons.person, color: Colors.white, size: 36),
                  ),
                  const SizedBox(width: 16),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Misafir Kullanıcı',
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                        ),
                        Text(
                          'İlerlemeyi cihazda saklanır.',
                          style: TextStyle(color: Colors.grey, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () {},
                    child: const Text('Giriş Yap'),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),

          const Text(
            'Egzersiz Tercihleri',
            style: TextStyle(fontWeight: FontWeight.bold, color: Colors.indigo, fontSize: 16),
          ),
          const SizedBox(height: 8),

          SwitchListTile(
            title: const Text('Varsayılan Odak Noktası'),
            subtitle: const Text('Kırmızı nokta egzersiz başlarken açık gelsin.'),
            value: isFocusRed,
            onChanged: (val) => setState(() => isFocusRed = val),
          ),
          SwitchListTile(
            title: const Text('Ses Efektleri'),
            subtitle: const Text('Kelime geçişleri ve testlerde sesli geri bildirim.'),
            value: isSoundOn,
            onChanged: (val) => setState(() => isSoundOn = val),
          ),

          const Divider(height: 30),

          const Text(
            'Uygulama Ayarları',
            style: TextStyle(fontWeight: FontWeight.bold, color: Colors.indigo, fontSize: 16),
          ),
          const SizedBox(height: 8),

          // DİNAMİK BİLDİRİM SAATİ SEÇİMİ
          ListTile(
            leading: const Icon(Icons.notifications_active, color: Colors.indigo),
            title: const Text('Günlük Çalışma Hatırlatıcısı'),
            subtitle: Text(
              isReminderOn
                  ? 'Her gün saat ${reminderTime.format(context)}\'de bildirim gönder.'
                  : 'Hatırlatıcı kapalı.',
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (isReminderOn)
                  IconButton(
                    icon: const Icon(Icons.access_time, color: Colors.indigo),
                    onPressed: () => _selectTime(context),
                  ),
                Switch(
                  value: isReminderOn,
                  onChanged: (val) => setState(() => isReminderOn = val),
                ),
              ],
            ),
          ),

          const Divider(height: 30),

          // SIFIRLAMA BUTONU
          ListTile(
            leading: const Icon(Icons.refresh, color: Colors.redAccent),
            title: const Text(
              'İlerlemeyi Sıfırla',
              style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold),
            ),
            onTap: _showResetDialog,
          ),
        ],
      ),
    );
  }
}