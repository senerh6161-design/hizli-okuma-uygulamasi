import 'dart:async';
import 'package:flutter/material.dart';
import '../../models/word_data.dart';
import '../../models/progress_manager.dart';

class LevelPage extends StatefulWidget {
  const LevelPage({super.key});

  @override
  State<LevelPage> createState() => _LevelPageState();
}

class _LevelPageState extends State<LevelPage> {
  // 5 Aşamalı Seviye Mimarisi (Süreler sabit, kelime zorluğu artar)
  final List<Map<String, dynamic>> levels = [
    {
      'title': 'Seviye 1 - Başlangıç',
      'desc': 'Tekli kısa kelimeler ve temel akış',
      'speed': 2000, // 2 saniye (Rahat okunabilir sabit süre)
      'isPair': false,
    },
    {
      'title': 'Seviye 2 - Temel',
      'desc': 'Orta uzunlukta tekli kelimeler',
      'speed': 2000,
      'isPair': false,
    },
    {
      'title': 'Seviye 3 - Gelişen',
      'desc': 'İkili kelime öbeklerine geçiş',
      'speed': 2000,
      'isPair': true,
    },
    {
      'title': 'Seviye 4 - Orta',
      'desc': 'Yoğun ikili kelime grupları',
      'speed': 2000,
      'isPair': true,
    },
    {
      'title': 'Seviye 5 - İleri',
      'desc': 'Uzun cümle öbekleri ve karmaşık akış',
      'speed': 2000,
      'isPair': true,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Hızlı Okuma Seviyeleri'),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: levels.length,
        itemBuilder: (context, index) {
          final lvl = levels[index];
          return Card(
            margin: const EdgeInsets.only(bottom: 14),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
            elevation: 2,
            child: ListTile(
              contentPadding: const EdgeInsets.all(18),
              leading: CircleAvatar(
                radius: 26,
                backgroundColor: const Color(0xFF4F46E5).withValues(alpha: 0.1),
                child: Text(
                  '${index + 1}',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF4F46E5),
                    fontSize: 18,
                  ),
                ),
              ),
              title: Text(
                lvl['title'],
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              subtitle: Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text('${lvl['desc']}\nSüre sabit: 2.0 sn'),
              ),
              trailing: const Icon(Icons.arrow_forward_ios, size: 16),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ActiveReadingSession(
                      levelTitle: lvl['title'],
                      speedMs: lvl['speed'],
                      isPair: lvl['isPair'],
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}

// AKTİF OKUMA EKRANI (WPM HESAPLAMALI VE CANLI)
class ActiveReadingSession extends StatefulWidget {
  final String levelTitle;
  final int speedMs;
  final bool isPair;

  const ActiveReadingSession({
    super.key,
    required this.levelTitle,
    required this.speedMs,
    required this.isPair,
  });

  @override
  State<ActiveReadingSession> createState() => _ActiveReadingSessionState();
}

class _ActiveReadingSessionState extends State<ActiveReadingSession> {
  Timer? timer;
  bool isRunning = false;
  int currentIndex = 0;
  int readCount = 0;
  int calculatedWpm = 0;
  
  late List<String> activeWords;

  @override
  void initState() {
    super.initState();
    // Seviyeye göre tekli veya ikili kelime havuzunu yükle
    activeWords = widget.isPair 
        ? WordData.getRandomPairs(30) 
        : WordData.getRandomSingleWords(30);
  }

  void startSession() {
    setState(() {
      isRunning = true;
      currentIndex = 0;
      readCount = 0;
    });

    timer = Timer.periodic(Duration(milliseconds: widget.speedMs), (t) {
      if (!mounted) return;
      
      setState(() {
        readCount++;
        // WPM Hesaplama Formülü: (Okunan Kelime Sayısı / Geçen Süre Dakika)
        // 2 saniyede 1 kelime/öbek akışı üzerinden ortalama WPM türetilir
        calculatedWpm = (readCount * (60000 / widget.speedMs)).round();

        if (currentIndex < activeWords.length - 1) {
          currentIndex++;
        } else {
          t.cancel();
          isRunning = false;
          _finishSession();
        }
      });
    });
  }

  void stopSession() {
    timer?.cancel();
    setState(() => isRunning = false);
  }

  void _finishSession() {
    ProgressManager.addCompletedExercise(
      type: widget.levelTitle,
      result: '$calculatedWpm WPM',
      newWpm: calculatedWpm,
    );

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('🎉 Oturum Tamamlandı!'),
        content: Text('Tebrikler! Bu oturumdaki performansınız:\n\nOrtalama Hız: $calculatedWpm WPM'),
        actions: [
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Seviyelere Dön'),
          )
        ],
      ),
    );
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final displayWord = activeWords[currentIndex];

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.levelTitle),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Text(
              'Başınızı ve dudaklarınızı oynatmadan, yalnızca gözlerinizle takip ediniz.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey, fontSize: 13),
            ),
            const SizedBox(height: 30),

            // OKUMA KARTI
            Expanded(
              child: Container(
                width: double.infinity,
                alignment: Alignment.center,
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: Colors.grey.shade300),
                ),
                child: Text(
                  isRunning ? displayWord : 'BAŞLA',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF4F46E5),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),

            // ALT İSTATİSTİK BARI (WPM CANLI GÖSTERİMİ)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Okunan: $readCount', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  Text('WPM: $calculatedWpm', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Color(0xFF4F46E5))),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // BAŞLAT / DURDUR BUTONU
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF4F46E5),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                onPressed: isRunning ? stopSession : startSession,
                icon: Icon(isRunning ? Icons.pause : Icons.play_arrow),
                label: Text(
                  isRunning ? 'DURAKLAT' : 'OKUMAYI BAŞLAT',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}