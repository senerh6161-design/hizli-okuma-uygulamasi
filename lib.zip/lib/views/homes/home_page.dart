import 'package:flutter/material.dart';
import '../../widgets/home_widgets.dart';
import '../../models/progress_manager.dart';
import '../levels/school_level_selection_page.dart';
import '../exercises/attention_exercise_page.dart';
import '../exercises/memory_exercise_page.dart';
import '../exercises/comprehension_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool isReadingDone = false;
  bool isAttentionDone = false;
  bool isMemoryDone = false;
  bool isComprehensionDone = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Hızlı Okuma Lab',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const WelcomeCard(),
            const SizedBox(height: 20),
            
            const Text(
              'Bugünkü Durum',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            
            // DİNAMİK SERVİSTEN ÇEKİLEN KARTLAR
            Row(
              children: [
                Expanded(
                  child: StatCard(
                    title: 'WPM',
                    value: '${ProgressManager.wpm}',
                    icon: Icons.speed,
                    color: Colors.indigo,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: StatCard(
                    title: 'Anlama',
                    value: '%${ProgressManager.comprehensionRate}',
                    icon: Icons.menu_book,
                    color: Colors.green,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: StatCard(
                    title: 'Seviye',
                    value: '${ProgressManager.currentLevel}',
                    icon: Icons.emoji_events,
                    color: Colors.orange,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: StatCard(
                    title: 'Tamamlanan',
                    value: '${ProgressManager.completedExercises}',
                    icon: Icons.check_circle_outline,
                    color: Colors.purple,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 25),

            const Text(
              'Bugünkü Çalışma',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),

            // GÖREVLER
            InkWell(
              onTap: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const SchoolLevelSelectionPage()),
                );
                setState(() => isReadingDone = true);
              },
              borderRadius: BorderRadius.circular(16),
              child: DailyTaskTile(
                icon: Icons.menu_book,
                title: 'Hızlı Okuma',
                subtitle: '5 dakika antrenman',
                completed: isReadingDone,
              ),
            ),

            InkWell(
              onTap: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const AttentionExercisePage()),
                );
                setState(() {
                  isAttentionDone = true;
                  ProgressManager.addCompletedExercise(type: 'Dikkat', result: 'Tamamlandı');
                });
              },
              borderRadius: BorderRadius.circular(16),
              child: DailyTaskTile(
                icon: Icons.visibility,
                title: 'Dikkat Egzersizi',
                subtitle: 'Target bulma matrisi',
                completed: isAttentionDone,
              ),
            ),

            InkWell(
              onTap: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const MemoryExercisePage()),
                );
                setState(() {
                  isMemoryDone = true;
                  ProgressManager.addCompletedExercise(type: 'Hafıza', result: 'Tamamlandı');
                });
              },
              borderRadius: BorderRadius.circular(16),
              child: DailyTaskTile(
                icon: Icons.psychology,
                title: 'Hafıza Egzersizi',
                subtitle: 'Kelimeleri hatırlama testi',
                completed: isMemoryDone,
              ),
            ),

            InkWell(
              onTap: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const ComprehensionPage()),
                );
                setState(() {
                  isComprehensionDone = true;
                  ProgressManager.addCompletedExercise(type: 'Anlama Testi', result: 'Tamamlandı');
                });
              },
              borderRadius: BorderRadius.circular(16),
              child: DailyTaskTile(
                icon: Icons.quiz,
                title: 'Anlama Testi',
                subtitle: 'Okuduğunu kavrama ölçümü',
                completed: isComprehensionDone,
              ),
            ),
          ],
        ),
      ),
    );
  }
}