import 'package:flutter/material.dart';
import '../../models/progress_manager.dart';

class ProgressPage extends StatefulWidget {
  const ProgressPage({super.key});

  @override
  State<ProgressPage> createState() => _ProgressPageState();
}

class _ProgressPageState extends State<ProgressPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('📈 İlerlemem'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Genel Performans',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 15),

            // DİNAMİK VERİ KARTLARI
            _progressCard('Ortalama WPM', '${ProgressManager.wpm}', Icons.speed, Colors.indigo),
            _progressCard('Anlama Oranı', '%${ProgressManager.comprehensionRate}', Icons.menu_book, Colors.green),
            _progressCard('Dikkat Başarısı', '%${ProgressManager.attentionSuccess}', Icons.visibility, Colors.orange),
            _progressCard('Tamamlanan Egzersiz', '${ProgressManager.completedExercises}', Icons.check_circle, Colors.purple),

            const SizedBox(height: 25),
            const Text(
              'Seviye İlerlemesi',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 15),

            // CANLI İLERLEME ÇUBUĞU
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Seviye ${ProgressManager.currentLevel}', style: const TextStyle(fontWeight: FontWeight.bold)),
                      Text('%${(ProgressManager.levelProgress * 100).round()}'),
                    ],
                  ),
                  const SizedBox(height: 12),
                  LinearProgressIndicator(
                    value: ProgressManager.levelProgress > 1.0 ? 1.0 : ProgressManager.levelProgress,
                    minHeight: 10,
                    borderRadius: const BorderRadius.all(Radius.circular(10)),
                  ),
                  const SizedBox(height: 15),
                  Text(
                    'Bir sonraki seviyeye ulaşmak için ${((1.0 - ProgressManager.levelProgress) * 10).round()} egzersiz daha tamamla.',
                    style: const TextStyle(color: Colors.grey),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 25),
            const Text(
              'Son Çalışmalar',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),

            // DİNAMİK GEÇMİŞ LİSTESİ
            ...ProgressManager.history.map((item) {
              return _historyItem(item['title']!, item['result']!, item['date']!);
            }),
          ],
        ),
      ),
    );
  }

  Widget _progressCard(String title, String value, IconData icon, Color color) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: color.withValues(alpha: .12),
            child: Icon(icon, color: color),
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          ),
          Text(
            value,
            style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 20),
          ),
        ],
      ),
    );
  }

  Widget _historyItem(String title, String result, String date) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
      ),
      child: Row(
        children: [
          const Icon(Icons.check_circle, color: Colors.green),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
                Text(date, style: const TextStyle(color: Colors.grey, fontSize: 12)),
              ],
            ),
          ),
          Text(
            result,
            style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.indigo),
          ),
        ],
      ),
    );
  }
}